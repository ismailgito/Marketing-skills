# Humanizer: AI Writing De-Slopper (English)

> **Note:**
> - This is the official English source that [Humanizer-zh](https://github.com/op7418/Humanizer-zh) was translated from: [blader/humanizer](https://github.com/blader/humanizer)
> - The Quick Checklist and Quality Scoring sections are adapted from [hardikpandya/stop-slop](https://github.com/hardikpandya/stop-slop), the same source the zh package credits for its own bonus sections
> - The base guide follows Wikipedia's [Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), maintained by WikiProject AI Cleanup

---

## About

Humanizer identifies and removes signs of AI-generated writing, rewriting text so it reads naturally and sounds like it has a person behind it.

Use it for:
- Editing or reviewing AI-generated content
- Making a draft sound more human
- Learning to spot common AI writing tells

## Install

### Option 1: One-line install via npx (recommended)

```bash
npx skills add https://github.com/blader/humanizer.git
```

### Option 2: Git clone

```bash
git clone https://github.com/blader/humanizer.git ~/.claude/skills/humanizer
```

### Option 3: Manual install

1. Download this folder (or the ZIP) locally.
2. Copy the `humanizer` folder into Claude Code's skills directory:
   - **macOS/Linux**: `~/.claude/skills/`
   - **Windows**: `%USERPROFILE%\.claude\skills\`
3. Confirm the folder looks like this:
   ```
   ~/.claude/skills/humanizer/
   ├── SKILL.md       # skill definition (English)
   └── README.md      # this file
   ```

### Verify install

Restart Claude Code (or reload skills), then type:

```
/humanizer
```

If it's installed correctly, the skill activates.

## Usage

### Basic usage

#### 1. Invoke the skill directly

```
/humanizer please humanize this text:

[paste your AI-generated text]
```

#### 2. Use it mid-conversation

```
Can you use humanizer to rewrite this so it sounds more natural:

This update stands as a testament to our commitment to innovation, showcasing
a seamless, intuitive, and robust user experience.
```

#### 3. Humanize a file's contents

```
/humanizer please humanize the content in article.md
```

### Example scenarios

#### Scenario 1: Marketing copy

**Input:**
```
/humanizer
Nestled in the heart of downtown, this café boasts a rich cultural heritage
and breathtaking decor. It stands as a vibrant focal point of the city's
coffee culture, offering guests a seamless, intuitive, and vibrant experience.
```

**Sample output:**
> The café has been downtown for three years, known for pour-over coffee and a space built out of a converted old warehouse.

#### Scenario 2: Academic abstract

**Input:**
```
/humanizer
This study delves into the pivotal role of machine learning in medical
diagnostics, underscoring its significance within the evolving healthcare
landscape. Additionally, it lays a solid foundation for future developments
in the field.
```

**Sample output:**
> This study looks at how machine learning is used for early lung cancer screening, drawing on 5,000 patient records from 2019-2023.

#### Scenario 3: Blog post

**Input:**
```
/humanizer
AI isn't just a technology, it's a revolution in how we think about the
future. Industry experts believe it will have a lasting impact on society
as a whole.
```

**Sample output:**
> I keep wondering how AI is actually going to change the way we work. Talked to a few product friends about it last week, one's excited, one's worried about layoffs, and the truth is probably somewhere boring in between.

## Patterns detected

This skill identifies and fixes **33 patterns** of AI writing, grouped into five categories:

### Content patterns (6)
1. Undue emphasis on significance, legacy, and broader trends
2. Undue emphasis on notability and media coverage
3. Superficial analyses with -ing endings
4. Promotional and advertisement-like language
5. Vague attributions and weasel words
6. Outline-like "Challenges and Future Prospects" sections

### Language and grammar patterns (7)
7. Overused "AI vocabulary" words
8. Avoidance of "is"/"are" (copula avoidance)
9. Negative parallelisms and tailing negations
10. Rule of three overuse
11. Elegant variation (synonym cycling)
12. False ranges
13. Passive voice and subjectless fragments

### Style patterns (6)
14. Em dashes (and en dashes)
15. Overuse of boldface
16. Inline-header vertical lists
17. Title case in headings
18. Emojis
19. Curly quotation marks

### Communication patterns (3)
20. Collaborative communication artifacts
21. Knowledge-cutoff disclaimers and speculative gap-filling
22. Sycophantic/servile tone

### Filler, hedging, and rhetorical patterns (11)
23. Filler phrases
24. Excessive hedging
25. Generic positive conclusions
26. Hyphenated word pair overuse
27. Persuasive authority tropes
28. Signposting and announcements
29. Fragmented headers
30. Diff-anchored writing
31. Manufactured punchlines and staccato drama
32. Aphorism formulas
33. Conversational rhetorical openers

The skill also includes **Detection Guidance**: a list of things that look like AI tells but aren't (clean grammar, curly quotes alone, one short sentence, etc.), and signs of genuine human writing worth preserving.

## Files

- **`SKILL.md`** — English skill definition
- **`README.md`** — this document

**Note:** for the Chinese version, see [Humanizer-zh](https://github.com/op7418/Humanizer-zh).

## Manual usage

### Basic process

1. **Identify AI patterns** — scan the text against the patterns listed in `SKILL.md`
2. **Rewrite the flagged spans** — swap in natural phrasing without inventing new facts
3. **Preserve the information** — every claim in the source survives the rewrite
4. **Match the voice** — formal, casual, or technical, whichever the piece calls for
5. **Add personality only where it belongs** — blog posts and opinion get a voice; reference and technical text stay neutral

### Key principle: clean isn't enough, it needs a pulse

Removing AI patterns is the baseline. Good writing needs an actual voice behind it:

- **Have an opinion** — react to the facts, don't just report them
- **Vary the rhythm** — mix short and long sentences
- **Let mixed feelings stand** — real people rarely have a clean take
- **Use "I" when it's honest** — first person isn't unprofessional
- **Allow a little mess** — perfect structure reads like an algorithm
- **Be specific about feelings** — swap the abstract for the concrete

#### Example

**Before (clean but soulless):**
> The new software update stands as a testament to the company's commitment to innovation. Additionally, it delivers a seamless, intuitive, and robust user experience, ensuring users can accomplish their goals efficiently.

**After (humanized):**
> The update adds batch processing, keyboard shortcuts, and offline mode. Early feedback from beta users has been positive, most report finishing tasks faster.

**What changed:**
- Cut the inflated symbolism ("stands as a testament to")
- Cut the AI vocabulary ("additionally")
- Cut the rule of three ("seamless, intuitive, and robust")
- Cut the superficial "-ing" tail ("ensuring...")
- Added concrete features and real feedback instead

## Contributing

Found an issue or want to improve this package? Open an issue or PR on [blader/humanizer](https://github.com/blader/humanizer) for the core skill, or on this package for the bundling/packaging.

## References

- [Wikipedia: Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing) — the original source guide
- [WikiProject AI Cleanup](https://en.wikipedia.org/wiki/Wikipedia:WikiProject_AI_Cleanup) — Wikipedia's AI cleanup project
- [blader/humanizer](https://github.com/blader/humanizer) — the original English project this package is built from
- [hardikpandya/stop-slop](https://github.com/hardikpandya/stop-slop) — source for the Quick Checklist and Quality Scoring sections
- [op7418/Humanizer-zh](https://github.com/op7418/Humanizer-zh) — the Chinese translation/adaptation this English package was requested alongside

## License

MIT. See `LICENSE`.

---

**Note:** this tool isn't meant to fool AI detectors — it's meant to make writing genuinely better. The best way to de-AI text is to give it a real human thought and voice.
